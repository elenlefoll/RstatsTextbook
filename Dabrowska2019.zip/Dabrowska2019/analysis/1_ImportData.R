# This R script imports the data necessary to complete Chapters 7-14 of the textbook "Data Analysis for the Language Sciences: A very gentle introduction to statistics and data visualisation in R" by Elen Le Foll (2025). The online version is available at: https://elenlefoll.github.io/RstatsTextbook/.

# The data comes from the online supplements of: Dąbrowska, Ewa. 2019. Experience, Aptitude, and Individual Differences in Linguistic Attainment: A Comparison of Native and Nonnative Speakers. Language Learning 69(S1). 72–100. https://doi.org/10.1111/lang.12323.

# The creation of an .RProj file and how to import the data is explained in Ch. 6: https://elenlefoll.github.io/RstatsTextbook/6_ImpoRtingData.html.

L1.data <- read.csv(file = "data/L1_data.csv",
                    header = TRUE,
                    sep = ",",
                    quote = "\"",
                    dec = ".")

L2.data <- read.csv(file = "data/L2_data.csv",
                    header = TRUE,
                    sep = ",",
                    quote = "\"",
                    dec = ".")
