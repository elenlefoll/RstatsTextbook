# This R script imports the data necessary to complete Chapters 7-14 of the textbook "Data Analysis for the Language Sciences: A very gentle introduction to statistics and data visualisation in R" by Elen Le Foll (2025). The online version is available at: https://elenlefoll.github.io/RstatsTextbook/.

# The data comes from the online supplements of: Dąbrowska, Ewa. 2019. Experience, Aptitude, and Individual Differences in Linguistic Attainment: A Comparison of Native and Nonnative Speakers. Language Learning 69(S1). 72–100. https://doi.org/10.1111/lang.12323.

# The process of data wrangling is explained in detail in Chapter 9: https://elenlefoll.github.io/RstatsTextbook/9_DataWrangling.html.

# Data import using the {here} library (see textbox in Section 6.5)
library(here)

L1.data <- read.csv(file = here("data", "L1_data.csv"))
L2.data <- read.csv(file = here("data", "L2_data.csv"))

# Pre-processing pipeline (see Section 9.8)
library(tidyverse)

L2.data <- L2.data |> 
  mutate(Participant = as.character(Participant)) |> 
  mutate(Group = "L2")  

L1.data <- L1.data |> 
  mutate(Group = "L1") |> 
  rename(EduTotal = EduYrs)

combined.data <- bind_rows(L1.data, L2.data) |>
  mutate(across(where(is.character), str_to_title)) |>
  mutate(across(where(is.character), str_trim)) |>
  mutate(OccupGroup = str_to_upper(OccupGroup)) |> 
  mutate(
    NativeLg = word(NativeLg, start = 1),
    NativeLg = word(NativeLg, start = 1, sep = fixed("/")),
    NativeLg = case_when(
      NativeLg == "Mandarine" ~ "Mandarin",
      NativeLg %in% c("Lithunanina", "Lithunanina", "Lituanian") ~ "Lithuanian",
      TRUE ~ NativeLg)) |> 
  mutate(NativeLgFamily = case_when(
    NativeLg == "Lithuanian" ~ "Baltic",
    NativeLg %in% c("Cantonese", "Mandarin", "Chinese") ~ "Chinese",
    NativeLg == "German" ~ "Germanic",
    NativeLg == "Greek" ~ "Hellenic",
    NativeLg %in% c("French", "Italian", "Spanish") ~ "Romance",
    NativeLg %in% c("Polish", "Russian") ~ "Slavic")) |> 
  mutate(across(where(is.character), factor))

# Save wrangled dataset as .rds file (see Section 9.9)
dir.create(file.path(here("data", "processed")))

saveRDS(combined.data, 
        file = here("data", "processed", "combined_L1_L2_data.rds"))

# Create and save cleaned versions of the L1 and L2 datasets for Chapters 11-13
L1.data <- combined.data |> 
  filter(Group == "L1")

saveRDS(L1.data, 
        file = here("data", "processed", "L1_data.rds"))

L2.data <- combined.data |> 
  filter(Group == "L2")

saveRDS(L2.data, 
        file = here("data", "processed", "L2_data.rds"))


